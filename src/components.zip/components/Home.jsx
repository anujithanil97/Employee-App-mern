import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {

  return (
    <div className='imagehome'>

        <div className="my_container">
            <h1> Welcome to the Employee Portal </h1>

        </div>
        <div className='scontainer'>
            <p>Please login to continue</p>
            <Link to = {"/admin-login"} className='btn btn-primary' style={{ width: '150px', marginLeft:'-45%', height: '40px'}}>Admin Login</Link>
            <Link to = {"/login-user"} className='btn btn-primary'  style={{ width: '150px', marginLeft:'5%', height: '40px'}}>User Login</Link>
        </div>

        <div className='containerbtn'>
           
        </div>




    </div>
  )
}

export default Home